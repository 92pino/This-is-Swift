//: [Previous](@previous)

import Foundation

/*:
 # Queue
 > queue는 FIFO (First In First Out) 선입 선출 ==> 먼저 들어온 요소가 가장 먼저 나가는 요소
*/

public struct Queue {
    fileprivate var array = LinkedList<Int>()
    
    // 맨 뒤에 배열 요소를 추가하는 메서드
    mutating func enqueue(_ element: Int) {
        
    }
}

//: [Next](@next)
