//: [Previous](@previous)

import Foundation

/*:
 # Linked List
 Linked List는 연속된 데이터 요소로, 각각의 아이템은 **node** 와 관련이 있다.
 
 ## Singly Linked Lists
 singly linked lists 각각의 노드는 **다음 노드**를 향한 링크 정보만 갖고 있다
 
 ## Doubly Linked Lists
 Doubly linked lists 각각의 노드는 **이전 노드와 다음 노드**에 대한 링크 정보를 갖고 있다
*/

// Node가 클래스인 이유
// 본질적으로 자체 유형의 다른 개체에 대한 참조를 포함하는 개체이기때문?
// Node는 Class를 사용해야되고 LinkedList는 Struct를 사용하는 이유에 대해서 찾아보면 좋을듯 (Struct vs Class)
// 참조 : https://stackoverflow.com/questions/48648089/linkedlist-in-swift-with-node-as-structure
public class Node {
    var value: String
    
    init(value: String) {
        self.value = value
    }
    
    // Next
    // 옵셔널인 이유
    // 마지막 노드의 다음 노드는 nil이기 때문에 옵셔널 선언
    var next: Node?
    
    // Previous
    // ARC 관련 공부 필요
    // 참조 : https://www.raywenderlich.com/966538-arc-and-memory-management-in-swift
    weak var previous: Node?
}

public class LinkedList {
    fileprivate var head: Node? // LinkedList의 첫번째 노드 표현
    private var tail: Node? // LinkedList의 마지막 노드 표현
    
    public var isEmpty: Bool {
        return head == nil
    }
    
    public var first: Node? {
        return head
    }
    
    public var last: Node? {
        return tail
    }
    
    public func append(value: String) {
        let newNode = Node(value: value)
        
        if let tailNode = tail {
            newNode.previous = tailNode
            tailNode.next = newNode
        } else {
            head = newNode
        }
        
        tail = newNode
    }
}

let dogBreeds = LinkedList()
dogBreeds.append(value: "Labrador")
dogBreeds.append(value: "Bulldog")

extension LinkedList: CustomStringConvertible {
    public var description: String {
        var text = "["
        var node = head
        
        while node != nil {
            text += "\(node!.value)"
            node = node!.next
            if node != nil {
                text += ", "
            }
        }
        
        return text + "]"
    }
    
    public func nodeAt(index: Int) -> Node? {
        if index >= 0 {
            var node = head
            var i = index
            
            while node != nil {
                if i == 0 { return node }
                i -= 1
                node = node!.next
            }
        }
        
        return nil
    }
    
    // 모든 노드 제거
    public func removeAll() {
        head = nil
        tail = nil
    }
    
    // 선택적 노드 제거
    public func remove(node: Node) -> String {
        let prev = node.previous
        print("Prev :", prev)
        let next = node.next
        print("Next :", next)
        
        if let prev = prev {
            prev.next = next
        } else {
            head = next
        }
        print("@@@@ :", next?.previous)
        next?.previous = prev
        
        if next == nil {
            tail = prev
        }
        
        print("Node :", node)
        
        node.previous = nil
        node.next = nil
        
        return node.value
    }
}

print(dogBreeds.nodeAt(index: 0))

dogBreeds.remove(node: dogBreeds.first!)
dogBreeds.remove(node: dogBreeds.last!)

print(dogBreeds)

//: [Next](@next)
