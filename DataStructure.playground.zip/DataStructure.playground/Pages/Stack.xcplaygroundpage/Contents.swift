import UIKit

//: [Previous](@previous)

/*:
 # stack
 > 맨 위에 요소를 추가하려면 push, 맨 위의 요소를 제거하려면 pop
 > stack은 LIFO (Last In First Out) 후입 선출 ==> 마지막으로 넣은 요소가 가장 먼저 나오는 요소
 
 ## push
 스택에 요소를 추가하기 위한 키워드.
 책 더미 위에 책을 추가하는 것으로 생각할 수 있다.
 
 ## peek
 Stack에서는 최상위 요소를 제외하고는 내용을 확인할 수 없는데 이때
 
*/


/// 기본적인 Stack
struct Stack {
    fileprivate var array: [String] = []
    
    /// Stack Push
    // 배열의 맨 앞에 추가하는 경우에는 O(n) 연산으로 모든 배열 요소들이 이동해야되서 비용이 많이 들지만 Stack의 경우 맨 뒤에 추가되므로 O(1)으로 배열의 크기에 관계없이 항상 동일한 시간이 걸린다.
    mutating func push(_ element: String) {
      array.append(element)
    }
    
    /// Stack Pop
    // String이 옵셔널인 이유는 처음에 스택이 비어있는 경우를 처리하기 위함
    mutating func pop() -> String? {
        // 배열의 마지막 요소 제거
        return array.popLast()
    }
    
    // Stack Peek
    // Stack의 가장 마지막 요소 확인
    func peek() -> String? {
        return array.last
    }
}

// stack의 내용이 변경되야 하므로 let 대신 var
var rwBookStack = Stack()

// Stack Push
rwBookStack.push("3D Games by Tutorials")

// Stack Pop
rwBookStack.pop()
rwBookStack.pop()   // 모든 배열 요소가 삭제되어있으므로 nil 반환

// Stack Peek
print(rwBookStack.peek())

print(rwBookStack)


extension Stack: CustomStringConvertible {
    var description: String {
        let topDivider = "---Stack---\n"
        let bottomDivider = "\n---Stack---\n"
        
        let stackElements = array.reversed().joined(separator: "\n")
        
        return topDivider + stackElements + bottomDivider
    }
}

var rwBookStack2 = Stack()
rwBookStack2.push("3D Games by Tutorials")
rwBookStack2.push("tvOS Apprentice")
rwBookStack2.push("iOS Apprentice")
rwBookStack2.push("Swift Apprentice")
print(rwBookStack2)

// Generic Stack
struct GenericStack<T> {
    fileprivate var array: [T] = []
    
    mutating func push(_ element: T) {
        array.append(element)
    }
    
    mutating func pop() -> T? {
        return array.popLast()
    }
    
    mutating func peek() -> T? {
        return array.last
    }
    
    var isEmpty: Bool {
        return array.isEmpty
    }
    
    var count: Int {
        return array.count
    }
}

extension GenericStack: CustomStringConvertible {
    var description: String {
        let topDivider = "---Stack---\n"
        let bottomDivider = "\n---Stack---\n"
        
        let stackElements = array.map { "\($0)" }.reversed().joined(separator: "\n")
        
        return topDivider + stackElements + bottomDivider
    }
}

var genericRwBookStack = GenericStack<Int>()
print(genericRwBookStack.isEmpty)
genericRwBookStack.push(123)
print(genericRwBookStack.isEmpty)

print(genericRwBookStack.count)

//: [Next](@next)
